﻿namespace PORTAFOLIO.Models
{
    public class Contactos
    { 
        public string Nombre { get; set; }
        public string email { get; set; }
        public string mensaje { get; set; }
    }
}
